"use strict";

// HTML ელემენტები
const taskForm = document.getElementById("taskForm");
const taskTitle = document.getElementById("taskTitle");
const taskDescription = document.getElementById("taskDescription");
const taskDate = document.getElementById("taskDate");
const taskList = document.getElementById("taskList");
const message = document.getElementById("message");
const searchInput = document.getElementById("searchInput");
const filterSelect = document.getElementById("filterSelect");
const sortSelect = document.getElementById("sortSelect");
const totalCount = document.getElementById("totalCount");
const pendingCount = document.getElementById("pendingCount");
const completedCount = document.getElementById("completedCount");
const emptyMessage = document.getElementById("emptyMessage");
const clearCompletedBtn = document.getElementById("clearCompletedBtn");
const clock = document.getElementById("clock");
const loadApiBtn = document.getElementById("loadApiBtn");
const apiMessage = document.getElementById("apiMessage");
const apiTaskList = document.getElementById("apiTaskList");

const STORAGE_KEY = "taskManagerTasks";
let tasks = loadTasks();
let messageTimer;

// უსაფრთხოად წაკითხვა localStorage-დან
function loadTasks() {
    try {
        const rawData = localStorage.getItem(STORAGE_KEY);
        if (rawData === null) return [];

        const parsed = JSON.parse(rawData);
        if (!Array.isArray(parsed)) return [];

        return parsed.filter(task =>
            task &&
            Number.isSafeInteger(task.id) &&
            typeof task.title === "string" &&
            typeof task.description === "string" &&
            typeof task.completed === "boolean" &&
            typeof task.createdAt === "string"
        );
    } catch (error) {
        console.error("შენახული დავალებების წაკითხვა ვერ მოხერხდა:", error);
        return [];
    }
}

function saveTasks() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
        return true;
    } catch (error) {
        console.error("localStorage-ში შენახვა ვერ მოხერხდა:", error);
        showMessage("ბრაუზერში მონაცემების შენახვა ვერ მოხერხდა.", "error");
        return false;
    }
}

// დროებითი შეტყობინება setTimeout()-ით
function showMessage(text, type = "success") {
    clearTimeout(messageTimer);
    message.textContent = text;
    message.className = `message ${type}`;

    messageTimer = setTimeout(() => {
        message.textContent = "";
        message.className = "message";
    }, 3500);
}

// ფორმის ვალიდაცია და ახალი ობიექტის დამატება
taskForm.addEventListener("submit", event => {
    event.preventDefault();

    const title = taskTitle.value.trim();
    const description = taskDescription.value.trim();
    const dueDate = taskDate.value;

    if (title.length < 2) {
        showMessage("სათაური უნდა შეიცავდეს მინიმუმ 2 სიმბოლოს.", "error");
        taskTitle.focus();
        return;
    }

    if (title.length > 100 || description.length > 500) {
        showMessage("სათაური ან აღწერა დასაშვებ სიგრძეს აჭარბებს.", "error");
        return;
    }

    if (dueDate) {
        const parsedDate = new Date(`${dueDate}T00:00:00`);
        if (Number.isNaN(parsedDate.getTime()) ||
            parsedDate.toISOString().slice(0, 10) !== dueDate) {
            showMessage("გთხოვ, მიუთითე სწორი თარიღი.", "error");
            return;
        }
    }

    const newTask = {
        id: Date.now(),
        title,
        description,
        dueDate,
        completed: false,
        createdAt: new Date().toISOString()
    };

    tasks.push(newTask);
    const saved = saveTasks();
    renderTasks();
    taskForm.reset();

    showMessage(
        saved ? "დავალება წარმატებით დაემატა!" : "დავალება დაემატა, მაგრამ შენახვა ვერ მოხერხდა.",
        saved ? "success" : "error"
    );
});

// უსაფრთხო თარიღის ფორმატირება
function formatDate(dateString) {
    if (!dateString) return "თარიღი მითითებული არ არის";
    const date = new Date(`${dateString}T00:00:00`);
    if (Number.isNaN(date.getTime())) return "არასწორი თარიღი";
    return date.toLocaleDateString("ka-GE", {
        year: "numeric",
        month: "long",
        day: "numeric"
    });
}

function renderTasks() {
    taskList.replaceChildren();

    const query = searchInput.value.trim().toLocaleLowerCase("ka");
    const filter = filterSelect.value;
    const sort = sortSelect.value;

    // filter() ერთდროულად ასრულებს ძიებასა და სტატუსით ფილტრაციას
    const visibleTasks = tasks
        .filter(task => {
            const title = task.title.toLocaleLowerCase("ka");
            const description = task.description.toLocaleLowerCase("ka");
            const matchesQuery = title.includes(query) || description.includes(query);

            let matchesStatus = true;
            if (filter === "pending") matchesStatus = !task.completed;
            else if (filter === "completed") matchesStatus = task.completed;

            return matchesQuery && matchesStatus;
        })
        .sort((a, b) => {
            if (sort === "newest") return b.id - a.id;
            if (sort === "oldest") return a.id - b.id;
            if (sort === "title") return a.title.localeCompare(b.title, "ka");
            if (sort === "date") {
                const dateA = a.dueDate || "9999-12-31";
                const dateB = b.dueDate || "9999-12-31";
                return dateA.localeCompare(dateB);
            }
            return 0;
        });

    // ობიექტების მასივიდან DOM ელემენტების შექმნა
    for (const task of visibleTasks) {
        const card = document.createElement("article");
        card.className = "task-card";
        if (task.completed) card.classList.add("completed");

        const title = document.createElement("h3");
        title.textContent = task.title;

        const description = document.createElement("p");
        description.className = "task-description";
        description.textContent = task.description || "აღწერა მითითებული არ არის";

        const due = document.createElement("p");
        due.className = "task-meta";
        due.textContent = `შესასრულებელი თარიღი: ${formatDate(task.dueDate)}`;

        const created = document.createElement("p");
        created.className = "task-meta";
        const createdDate = new Date(task.createdAt);
        created.textContent = `შექმნილია: ${Number.isNaN(createdDate.getTime())
            ? "უცნობია"
            : createdDate.toLocaleString("ka-GE")}`;

        const status = document.createElement("span");
        status.className = "status";
        status.textContent = task.completed ? "შესრულებულია" : "შესასრულებელია";

        const actions = document.createElement("div");
        actions.className = "task-actions";

        const toggleButton = document.createElement("button");
        toggleButton.type = "button";
        toggleButton.className = "button secondary";
        toggleButton.textContent = task.completed ? "შეუსრულებლად მონიშვნა" : "შესრულებულად მონიშვნა";
        toggleButton.addEventListener("click", () => toggleTask(task.id));

        const deleteButton = document.createElement("button");
        deleteButton.type = "button";
        deleteButton.className = "button delete-btn";
        deleteButton.textContent = "წაშლა";
        deleteButton.addEventListener("click", () => deleteTask(task.id));

        actions.append(toggleButton, deleteButton);
        card.append(title, description, due, created, status, actions);
        taskList.appendChild(card);
    }

    totalCount.textContent = String(tasks.length);
    completedCount.textContent = String(tasks.filter(task => task.completed).length);
    pendingCount.textContent = String(tasks.filter(task => !task.completed).length);

    emptyMessage.hidden = visibleTasks.length !== 0;
    if (visibleTasks.length === 0) {
        const heading = emptyMessage.querySelector("h3");
        const paragraph = emptyMessage.querySelector("p");
        if (tasks.length === 0) {
            heading.textContent = "ჯერ დავალებები არ არის";
            paragraph.textContent = "დაამატე პირველი დავალება ზემოთ მოცემული ფორმით.";
        } else {
            heading.textContent = "დავალება ვერ მოიძებნა";
            paragraph.textContent = "შეცვალე ძიების ტექსტი ან ფილტრი.";
        }
    }
}

function toggleTask(id) {
    tasks = tasks.map(task => task.id === id
        ? { ...task, completed: !task.completed }
        : task
    );
    saveTasks();
    renderTasks();
}

function deleteTask(id) {
    tasks = tasks.filter(task => task.id !== id);
    saveTasks();
    renderTasks();
    showMessage("დავალება წაიშალა.", "success");
}

clearCompletedBtn.addEventListener("click", () => {
    const completedTotal = tasks.filter(task => task.completed).length;
    if (completedTotal === 0) {
        showMessage("შესრულებული დავალებები არ არის.", "error");
        return;
    }

    tasks = tasks.filter(task => !task.completed);
    saveTasks();
    renderTasks();
    showMessage(`წაიშალა ${completedTotal} შესრულებული დავალება.`, "success");
});

// ძიება, ფილტრაცია და სორტირება
searchInput.addEventListener("input", renderTasks);
filterSelect.addEventListener("change", renderTasks);
sortSelect.addEventListener("change", renderTasks);

// Date და setInterval(): მიმდინარე დრო ახლდება ყოველ წამს
function updateClock() {
    const now = new Date();
    clock.dateTime = now.toISOString();
    clock.textContent = now.toLocaleString("ka-GE", {
        dateStyle: "medium",
        timeStyle: "medium"
    });
}
updateClock();
setInterval(updateClock, 1000);

// Fetch API: GET მოთხოვნა JSONPlaceholder-ზე
async function loadApiTasks() {
    loadApiBtn.disabled = true;
    apiMessage.textContent = "დავალებები იტვირთება...";
    apiMessage.className = "message";
    apiTaskList.replaceChildren();

    try {
        const response = await fetch("https://jsonplaceholder.typicode.com/todos?_limit=5");

        if (!response.ok) {
            throw new Error(`HTTP შეცდომა: ${response.status}`);
        }

        const data = await response.json();
        if (!Array.isArray(data)) {
            throw new Error("სერვერმა მოსალოდნელი მასივი არ დააბრუნა.");
        }

        data.forEach(todo => {
            const card = document.createElement("div");
            card.className = "api-card";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.checked = Boolean(todo.completed);
            checkbox.disabled = true;
            checkbox.setAttribute("aria-label", todo.completed ? "შესრულებულია" : "შეუსრულებელია");

            const content = document.createElement("div");
            const title = document.createElement("p");
            title.textContent = todo.title || "უსათაურო დავალება";

            const status = document.createElement("span");
            status.className = "api-status";
            status.textContent = `ID: ${todo.id} · ${todo.completed ? "შესრულებულია" : "შეუსრულებელია"}`;

            content.append(title, status);
            card.append(checkbox, content);
            apiTaskList.appendChild(card);
        });

        apiMessage.textContent = `წარმატებით ჩაიტვირთა ${data.length} დავალება.`;
        apiMessage.className = "message success";
    } catch (error) {
        console.error("API-დან მონაცემების მიღება ვერ მოხერხდა:", error);
        apiMessage.textContent = "ჩატვირთვა ვერ მოხერხდა. შეამოწმე ინტერნეტი და ხელახლა სცადე.";
        apiMessage.className = "message error";
    } finally {
        loadApiBtn.disabled = false;
    }
}

loadApiBtn.addEventListener("click", loadApiTasks);

// საწყისი DOM
renderTasks();
