type BookStatus = "ხელმისაწვდომია" | "არ არის ხელმისაწვდომი";
type StatusFilter = "all" | "available" | "unavailable";

interface BookData {
  id: number;
  title: string;
  author: string;
  year: number;
  status: BookStatus;
}

class Book implements BookData {
  constructor(
    public id: number,
    public title: string,
    public author: string,
    public year: number,
    public status: BookStatus = "ხელმისაწვდომია"
  ) {}
}

class Employee {
  constructor(public name: string) {}

  showName(): void {
    console.log(`თანამშრომლის სახელი: ${this.name}`);
  }
}

class Developer extends Employee {
  constructor(name: string, public language: string) {
    super(name);
  }

  writeCode(): string {
    return `${this.name} წერს კოდს ${this.language}-ზე.`;
  }
}

const employee = new Employee("გიორგი");
employee.showName();

const developer = new Developer("ნიკა", "TypeScript");
developer.showName();
console.log(developer.writeCode());

const books: Book[] = [
  new Book(1, "ვეფხისტყაოსანი", "შოთა რუსთაველი", 1712),
  new Book(2, "პატარა უფლისწული", "ანტუან დე სენტ-ეგზიუპერი", 1943),
  new Book(3, "1984", "ჯორჯ ორუელი", 1949),
  new Book(4, "დათა თუთაშხია", "ჭაბუა ამირეჯიბი", 1973),
  new Book(5, "დიდოსტატის მარჯვენა", "კონსტანტინე გამსახურდია", 1939),
  new Book(6, "ვეფხისტყაოსნის სამყარო", "სხვადასხვა ავტორი", 2020, "არ არის ხელმისაწვდომი")
];

const getElement = <T extends HTMLElement>(id: string): T => {
  const element = document.getElementById(id);
  if (!element) {
    throw new Error(`HTML ელემენტი ვერ მოიძებნა: #${id}`);
  }
  return element as T;
};

const bookForm = getElement<HTMLFormElement>("book-form");
const titleInput = getElement<HTMLInputElement>("book-title");
const authorInput = getElement<HTMLInputElement>("book-author");
const yearInput = getElement<HTMLInputElement>("book-year");
const searchInput = getElement<HTMLInputElement>("search-input");
const statusFilter = getElement<HTMLSelectElement>("status-filter");
const bookList = getElement<HTMLDivElement>("book-list");
const emptyState = getElement<HTMLDivElement>("empty-state");
const resultsLabel = getElement<HTMLSpanElement>("results-label");
const totalCount = getElement<HTMLParagraphElement>("total-count");
const availableCount = getElement<HTMLParagraphElement>("available-count");
const unavailableCount = getElement<HTMLParagraphElement>("unavailable-count");
const formHeading = getElement<HTMLHeadingElement>("form-heading");
const submitButton = getElement<HTMLButtonElement>("submit-button");
const cancelEditButton = getElement<HTMLButtonElement>("cancel-edit");
const formMessage = getElement<HTMLParagraphElement>("form-message");
const clearSearchButton = getElement<HTMLButtonElement>("clear-search");
const showDeveloperButton = getElement<HTMLButtonElement>("show-developer");
const developerMessage = getElement<HTMLParagraphElement>("developer-message");

let nextId = Math.max(0, ...books.map(book => book.id)) + 1;
let editingBookId: number | null = null;

function showMessage(message: string, type: "success" | "error"): void {
  formMessage.textContent = message;
  formMessage.className = `form-message ${type}`;
}

function updateStatistics(): void {
  totalCount.textContent = String(books.length);
  availableCount.textContent = String(
    books.filter(book => book.status === "ხელმისაწვდომია").length
  );
  unavailableCount.textContent = String(
    books.filter(book => book.status === "არ არის ხელმისაწვდომი").length
  );
}

function createTextElement<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  className: string,
  text: string
): HTMLElementTagNameMap[K] {
  const element = document.createElement(tag);
  element.className = className;
  element.textContent = text;
  return element;
}

function createActionButton(
  label: string,
  className: string,
  action: () => void
): HTMLButtonElement {
  const button = document.createElement("button");
  button.type = "button";
  button.className = `action-button ${className}`;
  button.textContent = label;
  button.addEventListener("click", action);
  return button;
}

function renderBooks(): void {
  const query = searchInput.value.trim().toLocaleLowerCase();
  const selectedStatus = statusFilter.value as StatusFilter;

  const filteredBooks = books.filter(book => {
    const matchesText =
      book.title.toLocaleLowerCase().includes(query) ||
      book.author.toLocaleLowerCase().includes(query);

    let matchesStatus = true;
    if (selectedStatus === "available") {
      matchesStatus = book.status === "ხელმისაწვდომია";
    } else if (selectedStatus === "unavailable") {
      matchesStatus = book.status === "არ არის ხელმისაწვდომი";
    }

    return matchesText && matchesStatus;
  });

  bookList.replaceChildren();
  updateStatistics();

  resultsLabel.textContent = `ნაჩვენებია ${filteredBooks.length} / ${books.length} წიგნი`;
  emptyState.hidden = filteredBooks.length !== 0;

  filteredBooks.forEach(book => {
    const card = document.createElement("article");
    card.className = "book-card";

    const top = document.createElement("div");
    top.className = "book-top";

    const heading = createTextElement("h3", "", book.title);
    const statusClass =
      book.status === "ხელმისაწვდომია" ? "available" : "unavailable";
    const badge = createTextElement("span", `status-badge ${statusClass}`, book.status);
    top.append(heading, badge);

    const author = createTextElement("p", "book-author", `ავტორი: ${book.author}`);
    const meta = document.createElement("div");
    meta.className = "book-meta";
    meta.append(
      createTextElement("span", "", `გამოცემის წელი: ${book.year}`),
      createTextElement("span", "", `ID: ${book.id}`)
    );

    const actions = document.createElement("div");
    actions.className = "book-actions";

    actions.append(
      createActionButton(
        book.status === "ხელმისაწვდომია" ? "მიუწვდომლად მონიშვნა" : "ხელმისაწვდომად მონიშვნა",
        "action-status",
        () => toggleBookStatus(book.id)
      ),
      createActionButton("რედაქტირება", "action-edit", () => startEditing(book.id)),
      createActionButton("წაშლა", "action-delete", () => deleteBook(book.id))
    );

    card.append(top, author, meta, actions);
    bookList.appendChild(card);
  });
}

function addBook(title: string, author: string, year: number): void {
  books.push(new Book(nextId, title, author, year));
  nextId += 1;
  renderBooks();
}

function toggleBookStatus(id: number): void {
  const book = books.find(item => item.id === id);
  if (!book) {
    showMessage("წიგნი ვერ მოიძებნა.", "error");
    return;
  }

  if (book.status === "ხელმისაწვდომია") {
    book.status = "არ არის ხელმისაწვდომი";
  } else {
    book.status = "ხელმისაწვდომია";
  }

  renderBooks();
}

function deleteBook(id: number): void {
  const index = books.findIndex(book => book.id === id);
  if (index === -1) {
    showMessage("წიგნი ვერ მოიძებნა.", "error");
    return;
  }

  const book = books[index];
  if (!book) return;

  if (!window.confirm(`ნამდვილად გსურს „${book.title}“-ის წაშლა?`)) {
    return;
  }

  books.splice(index, 1);

  if (editingBookId === id) {
    resetForm();
  }

  renderBooks();
}

function startEditing(id: number): void {
  const book = books.find(item => item.id === id);
  if (!book) {
    showMessage("წიგნი ვერ მოიძებნა.", "error");
    return;
  }

  editingBookId = id;
  titleInput.value = book.title;
  authorInput.value = book.author;
  yearInput.value = String(book.year);

  formHeading.textContent = "წიგნის რედაქტირება";
  submitButton.textContent = "ცვლილებების შენახვა";
  cancelEditButton.hidden = false;
  showMessage(`რედაქტირდება წიგნი ID: ${book.id}`, "success");

  getElement<HTMLElement>("form-panel").scrollIntoView({
    behavior: "smooth",
    block: "start"
  });
  titleInput.focus();
}

function resetForm(): void {
  editingBookId = null;
  bookForm.reset();
  formHeading.textContent = "ახალი წიგნის დამატება";
  submitButton.textContent = "＋ წიგნის დამატება";
  cancelEditButton.hidden = true;
  formMessage.textContent = "";
  formMessage.className = "form-message";
}

function saveBook(event: SubmitEvent): void {
  event.preventDefault();

  const title = titleInput.value.trim();
  const author = authorInput.value.trim();
  const yearText = yearInput.value.trim();
  const year = Number(yearText);

  if (!title || !author || !yearText) {
    showMessage("გთხოვ, შეავსე ყველა სავალდებულო ველი.", "error");
    return;
  }

  if (!Number.isInteger(year) || year < 1 || year > 2100) {
    showMessage("გამოცემის წელი უნდა იყოს მთელი რიცხვი 1-დან 2100-მდე.", "error");
    return;
  }

  if (editingBookId !== null) {
    const book = books.find(item => item.id === editingBookId);
    if (!book) {
      showMessage("რედაქტირებადი წიგნი ვერ მოიძებნა.", "error");
      resetForm();
      return;
    }

    book.title = title;
    book.author = author;
    book.year = year;
    renderBooks();
    resetForm();
    showMessage("წიგნის მონაცემები წარმატებით განახლდა.", "success");
  } else {
    addBook(title, author, year);
    resetForm();
    showMessage("წიგნი წარმატებით დაემატა კატალოგს.", "success");
  }
}

bookForm.addEventListener("submit", saveBook);
searchInput.addEventListener("input", renderBooks);
statusFilter.addEventListener("change", renderBooks);

clearSearchButton.addEventListener("click", () => {
  searchInput.value = "";
  statusFilter.value = "all";
  renderBooks();
  searchInput.focus();
});

cancelEditButton.addEventListener("click", resetForm);

showDeveloperButton.addEventListener("click", () => {
  developerMessage.hidden = false;
  developerMessage.textContent = developer.writeCode();
});

renderBooks();
